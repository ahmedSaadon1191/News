<?php

namespace App\Http\Controllers\User;

use App\Models\Post;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class frontEndController extends Controller
{
    public function welcome()
    {
        $categories = Category::remove()->with('sub_category', 'posts')->get();

        // NEWS POSTS
        $chunk_news = Post::where('category_id', 1)->remove()->get();
        $chunk_news = $chunk_news->chunk(6);

        // reports POSTS
        $chunk_reports = Post::where('category_id', 2)->remove()->get();
        $chunk_reports = $chunk_reports->chunk(4);

        // the press POSTS
        $press = Post::where('category_id', 3)->remove()->get();
        $chunk_press = $press->chunk(3);

        // the Figures POSTS
        $Figures = Post::where('category_id', 4)->remove()->get();
        $chunk_Figures = $Figures->chunk(3);

        // the Opinion POSTS
        $Opinion = Post::where('category_id', 5)->remove()->get();
        $chunk_Opinion = $Opinion->chunk(3);

        // sports POSTS
        $sports = Post::where('category_id', 6)->remove()->get();
        $chunk_sports = $sports->chunk(4);

        // mix POSTS
        $chunk_mix = Post::where('category_id', 7)->remove()->get();
        $chunk_mix = $chunk_mix->chunk(5);

        // Economie POSTS
        $chunk_economie = Post::where('category_id', 8)->remove()->get();
        $chunk_economie = $chunk_economie->chunk(3);

        // Society POSTS
        $chunk_Society = Post::where('category_id', 9)->remove()->get();
        $chunk_Society = $chunk_Society->chunk(3);

        // most read of week POSTS
        $chunk_read_week = Post::where('category_id', 2)->remove()->get();
        $chunk_read_week = $chunk_read_week->chunk(4);


        // most read POSTS
        $chunk_most_read = Post::remove()->orderBy('read_count')->get();
        $chunk_most_read = $chunk_most_read->chunk(4);


        $LastPosts = Post::orderBy('id', 'desc')->take(5)->remove()->get();

        return view('frontEnd.welcome', compact(
            'categories',
            'chunk_reports',
            'chunk_news',
            'chunk_press',
            'chunk_Figures',
            'chunk_Figures',
            'chunk_Opinion',
            'chunk_sports',
            'chunk_mix',
            'chunk_economie',
            'chunk_Society',
            'chunk_read_week',
            'chunk_most_read',
            'LastPosts'
        ));
    }



    public function next_reports(Request $request)
    {

        $posts = Post::where('category_id', 2)->remove()->where('id', '<', $request->id)->limit(4)->orderBy('id', 'desc')->get();
        return \response()->json($posts);
    }

    public function back_reports(Request $request)
    {
        $posts_back = Post::where('category_id', 2)->remove()->where('id', '>', $request->id)->take(4)->get();
        return \response()->json($posts_back);
    }

    public function next_sport(Request $request)
    {
        $posts = Post::where('category_id', 8)->remove()->where('id', '<', $request->id)->limit(4)->orderBy('id', 'desc')->get();
        return \response()->json($posts);
    }


    public function back_sport(Request $request)
    {
        $posts_back = Post::where('category_id', 8)->remove()->where('id', '>', $request->id)->take(4)->get();
        return \response()->json($posts_back);
    }


    public function next_mix(Request $request)
    {
        $posts = Post::where('category_id', 7)->remove()->where('id', '<', $request->id)->limit(4)->orderBy('id', 'desc')->get();
        return \response()->json($posts);
    }

    public function back_mix(Request $request)
    {
        $posts_back = Post::where('category_id', 7)->remove()->where('id', '>', $request->id)->take(4)->get();
        return \response()->json($posts_back);
    }

    public function search(Request $request)
    {
        $categories       = Category::where('t.name', 'LIKE', "%{$request->search}%")->remove()->first();
        return $categories;
    }


    // public function test()
    // {
    //     return view('test');
    // }
}

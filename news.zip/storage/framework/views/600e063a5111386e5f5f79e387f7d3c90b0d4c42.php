<div class="container main-container">
    <div class="hero mt-4">

        <?php if($LastPosts->count() > 0): ?>
            <div class="row p-md-0">

                <?php
                    $number = 0;
                    $number2 = 0;

                ?>

                <?php $__currentLoopData = $LastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $number = ++$number;
                    ?>

                    <?php if($number == 1): ?>
                        <a href="#" class="col-md-6 p-md-0">
                            <div class="for_new_post"
                                style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                                <div class="overray"></div>
                                <div class="post_content">
                                    <h6 class="mb-4">il y a 1 minute</h6>
                                    <h3>
                                        LastPosts
                                    </h3>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-6">
                    <div class="row pt-2 pt-md-0 p-2 p-md-0">
                        <?php $__currentLoopData = $LastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $number2 = ++$number2;
                            ?>


                                    <?php if($number2 > 1): ?>
                                        <a href="#" class="col-6 box_for_new_post_small">
                                            <div class="for_new_post_small"
                                                style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                                                <div class="overray"></div>
                                                <div class="post_content">
                                                    <p>il y a 1 minute</p>
                                                    <h6>
                                                        <?php echo e($item->id); ?>

                                                    </h6>
                                                </div>
                                            </div>
                                        </a>
                                    <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/layout/hero.blade.php ENDPATH**/ ?>
<?php echo $__env->make('frontEnd.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    
    <?php echo $__env->make('frontEnd.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- start hero section -->
    <?php echo $__env->make('frontEnd.layout.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End hero section -->

    <!-- start main section -->
    <div class="container p-md-0 mt-4">
        <div class="row p-0">

            <div class="col-md-8 mb-4">
                <!-- start news section -->
                <?php echo $__env->make('frontEnd.layout.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- end news section -->

                <!-- advertisement widget-->
                <div class="card mb-4 col-12">
                    <div class="card-body text-center">
                        <img src="assets/img/adv2.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start reports section -->
                <?php echo $__env->make('frontEnd.layout.reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- start reports section -->

                <!-- End reports section -->

                <!-- End reports section -->


                <div class="row mt-4">
                    <!-- start the press section -->
                    <?php echo $__env->make('frontEnd.layout.press', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                    <!-- start Figures section -->
                    <?php echo $__env->make('frontEnd.layout.figures', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                </div>


                <!-- Start opinion section -->
                <?php echo $__env->make('frontEnd.layout.opinion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- advertisement widget-->
                <div class="card mb-4 col-12 mt-3">
                    <div class="card-body text-center">
                        <img src="assets/img/adv3.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start sports section -->
                <?php echo $__env->make('frontEnd.layout.sports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- End sports section -->

                <!-- start Mix section -->
                <?php echo $__env->make('frontEnd.layout.mix', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- End Mix section -->


            </div>


            <div class="col-md-4">
                <!-- Search widget-->
                <div class="card mb-4">
                    <div class="card-header">Search</div>
                    <div class="card-body">
                        <div class="input-group">
                            <input class="form-control" type="text" placeholder="Enter search term..."
                                aria-label="Enter search term..." aria-describedby="button-search" />
                            <button class="btn btn-primary" id="button-search" type="button">Go!</button>
                        </div>
                    </div>
                </div>
                <!-- advertisement widget-->
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="assets/img/adv1.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- Categories widget-->
                <div class="card mb-4">
                    <div class="card-header">Categories</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#!">Web Design</a></li>
                                    <li><a href="#!">HTML</a></li>
                                    <li><a href="#!">Freebies</a></li>
                                </ul>
                            </div>
                            <div class="col-sm-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#!">JavaScript</a></li>
                                    <li><a href="#!">CSS</a></li>
                                    <li><a href="#!">Tutorials</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- for Most Read of the Week widget-->
                <?php echo $__env->make('frontEnd.layout.read_week', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- start Economie section -->
                <?php echo $__env->make('frontEnd.layout.economie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- start Society section -->
                <?php echo $__env->make('frontEnd.layout.society', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- for Most Read widget-->
                <?php echo $__env->make('frontEnd.layout.most_read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <!-- start Economie section -->
                <div class="the_press_section">
                    <div class="card card-body ">
                        <h5>Follow Us</h5>
                        <div class="row social_follow mt-4">
                            <div class="col-3">
                                <i class="bi bi-facebook"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-whatsapp"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-youtube"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-twitter"></i>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('frontEnd.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/welcome.blade.php ENDPATH**/ ?>
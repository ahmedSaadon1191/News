<div class="card card-body pt-1 sports_section MyHover_green">
    <div class="row card_title">
        <div class="col-6">
            <h4>sports</h4>
        </div>
        <div class="col-6 text-end btn_controller_slider">
            <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_sports"
                    data-bs-slide="next"></i>
            </button>
            <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_sports"
                    data-bs-slide="prev"></i>
            </button>
        </div>
    </div>

      <div id="carouselExampleControls_sports" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
        <div class="carousel-inner repoerts_carousel">


            <?php for($x = 0; $x < $chunk_sports->count(); $x++): ?>

                <div class="carousel-item">
                    <div class="row mt-2 card_small_reports">
                        <?php
                            $number = 0;
                        ?>

                        <?php $__currentLoopData = $chunk_sports[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $number = ++$number;
                        ?>

                        <?php if($number == 1): ?>
                            <a href="post.html" class="main_post_for_reports mb-3"
                                style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                                <div class="overray"></div>
                                <div class="post_content">
                                    <h6 class="mb-4">il y a 1 minute</h6>
                                    <h3>
                                        Le président nigérian met en garde contre une intervention étrangère dans
                                        les
                                        prochaines
                                        élections présidentielles
                                    </h3>
                                </div>
                            </a>
                        <?php else: ?>
                            <a href="post.html" class="col-6 col-md-4">
                                <div class="img_for_reports" style="background-image: url('assets/frontEnd/img/carousel-3.jpg')"></div>

                                <div class="date mb-1 mt-1 small_text">
                                    <i class="bi bi-clock"></i>
                                    <span>il y a 11 minutes</span>
                                </div>
                                <h6>title here</h6>
                            </a>
                        <?php endif; ?>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            <?php endfor; ?>

        </div>

    </div>

</div>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/layout/sports.blade.php ENDPATH**/ ?>
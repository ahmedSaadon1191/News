<!DOCTYPE html>
<?php if(App::getLocale() == 'fr'): ?>
    <html lang="en">
<?php else: ?>
    <html lang="ar" dir="rtl">
<?php endif; ?>


<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Blog - Home Page</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->



    <link href="assets/frontEnd/css/myStyle.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    
    <?php if(App::getLocale() == 'fr'): ?>
        <link href="assets/frontEnd/css/styles.css" rel="stylesheet" />
        <?php else: ?>
        <link href="assets/frontEnd/css/bootstrap_rtl.css" rel="stylesheet" />
        <link href="assets/frontEnd/css/styles.css" rel="stylesheet" />
        <link href="assets/frontEnd/css/rtl.css" rel="stylesheet" />

    <?php endif; ?>
    





</head>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/layout/header.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    اضافه مورد
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="mb-2">
            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-danger">رجوع</a>
        </div>

        <div class="card shadow">
            <div class="card-header">
                <h5>عرض تفاصيل المقال <?php echo e($post->getTranslation('title','ar')); ?></h5>
                <div style="text-align: center">
                    <img class="img-responsive mb-1" src="<?php echo e(asset('/assets/images/' . $post->photo)); ?>" style="height: 100px; width: 100px; text-align: center">
                </div>
            </div>

            <div class="card-body">
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                      العنوان بالعربي
                      <span class="badge-pill"><?php echo e($post->getTranslation('title','ar')); ?></span>
                    </li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        العنوان بالفرنسي
                        <span class="badge-pill"><?php echo e($post->getTranslation('title','fr')); ?></span>
                    </li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                    القسم الرئيسي
                    <span class="badge-pill"><?php echo e($post->category->getTranslation('name','ar')); ?></span>
                    </li>


                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        القسم الفرعي
                        <?php if(isset($post->sub_category)): ?>
                            <span class="badge-pill"><?php echo e($post->sub_category->getTranslation('name','ar')); ?></span>
                        <?php endif; ?>
                    </li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                         تفاصيل المقال بالعربي
                        <span class="badge-pill"><?php echo e($post->getTranslation('body','ar')); ?></span>
                    </li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        تفاصيل المقال بالفرنسي
                       <span class="badge-pill"><?php echo e($post->getTranslation('body','fr')); ?></span>
                   </li>


                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        حالة المقال
                            <span class="badge-pill"><?php echo e($post->type()); ?></span>
                    </li>

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        انشاء بواسطة

                        <span class="badge-pill"><?php echo e($post->user->name); ?></span>

                    </li>


                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        تاريخ الانشاء
                        <span class="badge-pill"><?php echo e($post->created_at); ?></span>

                    </li>

                  </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\news\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>
<div class="card card-body pt-1 MyHover_red">
    <div class="row card_post_title">
        <div class="col-6">
            <h4>reports</h4>
        </div>

        <div class="col-6 text-end btn_controller_slider">
            <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_reports" data-bs-slide="next"></i></button>
            <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_reports" data-bs-slide="prev"></i></button>
        </div>

    </div>

    <!-- ==================== -->

        <div id="carouselExampleControls_reports" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="row mt-2 card_small_reports">

                        <a href="post.html" class="main_post_for_reports mb-3"
                            style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                            <div class="overray"></div>
                            <div class="post_content">
                                <h6 class="mb-4">il y a 1 minute</h6>
                                <h3>
                                    Le président nigérian met en garde contre une intervention étrangère dans les
                                    prochaines
                                    élections présidentielles
                                </h3>
                            </div>
                        </a>


                        <a href="post.html" class="col-6 col-md-4">
                            <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                            <div class="date mb-1 mt-1 small_text">
                                <i class="bi bi-clock"></i>
                                <span>il y a 11 minutes</span>
                            </div>
                            <h6>title here</h6>
                        </a>
                        <a href="post.html" class="col-6 col-md-4">
                            <img src="assets/frontEnd/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                            <div class="date mb-1 mt-1 small_text">
                                <i class="bi bi-clock"></i>
                                <span>il y a 11 minutes</span>
                            </div>
                            <h6>title here</h6>
                        </a>
                        <a href="post.html" class="col-6 col-md-4">
                            <img src="assets/frontEnd/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                            <div class="date mb-1 mt-1 small_text">
                                <i class="bi bi-clock"></i>
                                <span>il y a 11 minutes</span>
                            </div>
                            <h6>title here</h6>
                        </a>


                    </div>
                  </div>
              <div class="carousel-item">
                <div class="row mt-2 card_small_reports">

                    <a href="post.html" class="main_post_for_reports mb-3"
                        style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                        <div class="overray"></div>
                        <div class="post_content">
                            <h6 class="mb-4">il y a 1 minute</h6>
                            <h3>
                                Le président nigérian met en garde contre une intervention étrangère dans les
                                prochaines
                                élections présidentielles
                            </h3>
                        </div>
                    </a>


                    <a href="post.html" class="col-6 col-md-4">
                        <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                        <div class="date mb-1 mt-1 small_text">
                            <i class="bi bi-clock"></i>
                            <span>il y a 11 minutes</span>
                        </div>
                        <h6>title here</h6>
                    </a>
                    <a href="post.html" class="col-6 col-md-4">
                        <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                        <div class="date mb-1 mt-1 small_text">
                            <i class="bi bi-clock"></i>
                            <span>il y a 11 minutes</span>
                        </div>
                        <h6>title here</h6>
                    </a>
                    <a href="post.html" class="col-6 col-md-4">
                        <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                        <div class="date mb-1 mt-1 small_text">
                            <i class="bi bi-clock"></i>
                            <span>il y a 11 minutes</span>
                        </div>
                        <h6>title here</h6>
                    </a>


                </div>
              </div>
              <div class="carousel-item">
                <div class="row mt-2 card_small_reports">

                    <a href="post.html" class="main_post_for_reports mb-3"
                        style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                        <div class="overray"></div>
                        <div class="post_content">
                            <h6 class="mb-4">il y a 1 minute</h6>
                            <h3>
                                Le président nigérian met en garde contre une intervention étrangère dans les
                                prochaines
                                élections présidentielles
                            </h3>
                        </div>
                    </a>


                    <a href="post.html" class="col-6 col-md-4">
                        <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                        <div class="date mb-1 mt-1 small_text">
                            <i class="bi bi-clock"></i>
                            <span>il y a 11 minutes</span>
                        </div>
                        <h6>title here</h6>
                    </a>
                    <a href="post.html" class="col-6 col-md-4">
                        <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                        <div class="date mb-1 mt-1 small_text">
                            <i class="bi bi-clock"></i>
                            <span>il y a 11 minutes</span>
                        </div>
                        <h6>title here</h6>
                    </a>
                    <a href="post.html" class="col-6 col-md-4">
                        <img src="assets/frontEnd/img/carousel-3.jpg" class="img-fluid" alt="">
                        <div class="date mb-1 mt-1 small_text">
                            <i class="bi bi-clock"></i>
                            <span>il y a 11 minutes</span>
                        </div>
                        <h6>title here</h6>
                    </a>


                </div>
              </div>
            </div>



        </div>


    <!-- ========================= -->


</div>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/reports.blade.php ENDPATH**/ ?>
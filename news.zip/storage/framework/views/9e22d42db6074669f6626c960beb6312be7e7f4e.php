<div class="card mb-4 mt-4">
    <div class="card card-body MyHover_blue">
        <div class="row card_title mb-2">
            <div class="col-6">
                <h5 class="text-success">Most Read</h5>
            </div>

            <div class="col-6 text-end btn_controller_slider pb-2">
                <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_most"
                        data-bs-slide="next"></i>
                </button>
                <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_most"
                        data-bs-slide="prev"></i>
                </button>
            </div>
        </div>

        <div id="carouselExampleControls_most" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
            <div class="carousel-inner repoerts_carousel">

                <?php if($chunk_most_read->count() > 0): ?>
                    <?php
                        $myNumber = 0;
                    ?>
                    <?php for($x = 0; $x < $chunk_most_read->count(); $x++): ?>

                        <div class="carousel-item">
                            <div class="row col-12 m-auto">

                                <?php $__currentLoopData = $chunk_most_read[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <a href="#" class="row mb-2 mt-4">
                                        <div class="col-6 most_read_count">
                                            <div class="most_read_count_1">
                                                <?php echo e(++$myNumber); ?>

                                            </div>
                                            <div class="img_for_most_read" style="background-image: url('assets/frontEnd/img/carousel-3.jpg')"></div>
                                        </div>
                                        <div class="col-6 p-0">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                            <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                                        </div>
                                    </a>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    <?php endfor; ?>
                <?php endif; ?>



            </div>

        </div>



    </div>
</div>




<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/layout/most_read.blade.php ENDPATH**/ ?>
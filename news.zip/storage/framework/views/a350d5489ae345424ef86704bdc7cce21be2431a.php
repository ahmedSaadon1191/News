<div class="card card-body pt-1 mb-3 MyHover_red">
    <div class="row card_post_title">
        <div class="col-6">
            <h4>News</h4>
        </div>

        <div class="col-6 text-end btn_controller_slider">
            <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_news"
                    data-bs-slide="next"></i>
            </button>
            <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_news"
                    data-bs-slide="prev"></i>
            </button>
        </div>

    </div>

    <div id="carouselExampleControls_news" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
        <div class="carousel-inner repoerts_carousel">

            <?php if($chunk_news->count() > 0): ?>
                <?php for($x = 0; $x < $chunk_news->count(); $x++): ?>

                    <div class="carousel-item">
                        <div class="row mt-2 card_small_news">

                            <?php $__currentLoopData = $chunk_news[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#" class="col-md-6 mt-4">
                                    <div>
                                        <div class="date text-black-50 mb-1">
                                            <i class="bi bi-clock"></i>
                                            <span><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForhumans()); ?></span>
                                        </div>
                                        <h5><?php echo e($item->title); ?></h5>
                                    </div>

                                    <div class="row">
                                        <div class="col-4">
                                            <div class="img_for_news" style="background-image: url('assets/images/<?php echo e($item->photo); ?>')"></div>

                                        </div>
                                        <div class="col-8">
                                            <div class="desc">

                                                <p><?php echo e(substr($item->body,0,140)); ?> ... </p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                <?php endfor; ?>
            <?php endif; ?>


        </div>

    </div>

</div>
<?php /**PATH C:\Users\Dell\Desktop\news\resources\views/frontEnd/layout/news.blade.php ENDPATH**/ ?>
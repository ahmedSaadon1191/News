<div class="card card-body pt-1 mix_section mt-4 MyHover">
    <div class="row card_title">
        <div class="col-6">
            <h4>Mix</h4>
        </div>

        <div class="col-6 text-end btn_controller_slider">
            <button><i class="bi bi-chevron-right" data-bs-target="#carouselExampleControls_mix"
                    data-bs-slide="next"></i>
            </button>
            <button><i class="bi bi-chevron-left" data-bs-target="#carouselExampleControls_mix"
                    data-bs-slide="prev"></i>
            </button>
        </div>

    </div>

    <!-- ====================-->

    <div id="carouselExampleControls_mix" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
        <div class="carousel-inner repoerts_carousel">


            <?php for($x = 0; $x < $chunk_mix->count(); $x++): ?>

                <div class="carousel-item">
                    <div class="row mt-2 card_small_reports">
                        <?php
                            $number = 0;
                        ?>

                        <?php $__currentLoopData = $chunk_mix[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $number = ++$number;
                            ?>

                            <?php if($number == 1): ?>
                                <div class="col-md-6">
                                    <div class="main_post_for_mix mb-4"
                                        style="background-image: url('assets/frontEnd/img/carousel-1.jpg');">
                                        <div class="overray"></div>
                                        <div class="post_content">
                                            <h6 class="mb-4">il y a 1 minute</h6>
                                            <h3>
                                                Le président nigérian met en garde contre une intervention étrangère dans les
                                                prochaines
                                                élections présidentielles
                                            </h3>
                                        </div>
                                    </div>

                                </div>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-6">
                            <?php
                                $number = 0;
                            ?>
                            <?php $__currentLoopData = $chunk_mix[$x]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $number = ++$number;
                                ?>

                                <?php if($number > 1): ?>

                                    <div class="col-12 row mb-4">
                                        <div class="col-5">
                                            <div class="img_for_news" style="background-image: url('assets/frontEnd/img/القصر.webp')"></div>
                                        </div>
                                        <div class="col-7">
                                            <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                            <h6>title here</h6>
                                        </div>
                                    </div>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>


                    </div>
                </div>

            <?php endfor; ?>

        </div>

    </div>


    <!-- ========================= -->


</div>
<?php /**PATH D:\programming 2022\php\laravel blog\Blog\asaadon1191-news-website-b0de9134485b\resources\views/frontEnd/layout/mix.blade.php ENDPATH**/ ?>
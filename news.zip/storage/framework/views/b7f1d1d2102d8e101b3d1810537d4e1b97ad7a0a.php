<body>

    <!-- top bar -->
    <div class="top_bar d-none d-md-block">
        <div class="container">
            <div class="row p-1">
                <div class="col-md-6">
                    <i class="bi bi-clock"></i>
                    <span><?php echo e(Carbon\Carbon::now()); ?></span>
                </div>
                <div class="col-md-6 text-end">
                    <a href="">
                        <i class="bi bi-facebook ps-3"></i>
                    </a>
                    <a href="">
                        <i class="bi bi-twitter ps-3"></i>
                    </a>
                    <a href="">
                        <i class="bi bi-youtube ps-3"></i>
                    </a>
                    <a href="">
                        <i class="bi bi-instagram ps-3"></i>
                    </a>

                </div>
            </div>
        </div>
    </div>

    <!-- Page header with logo and tagline-->
    <header class="bg-light border-bottom d-none d-md-block">
        <div class="container">
            <div class="text-center my-1">
                <img width="150px" height="150px" src="<?php echo e(asset('assets/frontEnd/img/logo.png')); ?>" alt="" class="img-fluid">
            </div>
        </div>
    </header>


    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary myNavbar" style="background-color: #32C36C !important">
        <div class="container">
            <div class="navbar-brand d-md-none">
                <img width="60px" height="60px" src="<?php echo e(asset('assets/frontEnd/img/logo.png')); ?>" alt=""
                    class="img-fluid">
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse m-auto text-left" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('welcome.frontEnd')); ?>">
                            <?php echo e(__('navbar.home')); ?>

                        </a>
                    </li>
                     <?php if(isset($categories) && $categories->count() > 0): ?>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item dropdown has-megamenu">
                                <a class="nav-link dropdown-toggle" href="#"
                                    data-bs-toggle="dropdown"><?php echo e($category->name); ?></a>
                                <div class="dropdown-menu megamenu" role="menu">
                                    <!-- for disktop -->
                                    <div class=" d-none d-md-block ">
                                        <div class="row">

                                            <?php
                                                $posts = $category
                                                    ->posts()
                                                    ->latest()
                                                    ->take(4)
                                                    ->get();
                                            ?>

                                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-3 text-black">
                                                    <div class="p-2">
                                                        <div class="my_box_img" style="background-image: url('<?php echo e(asset('/assets/frontEnd/img/القصر.webp')); ?>');"></div>

                                                        <h6 class="mt-2"><?php echo e($post->title); ?></h6>
                                                        <div class="date mb-1 mt-1 small_text">
                                                            <i class="bi bi-clock"></i>
                                                            <span><?php echo e($post->created_at); ?></span>
                                                            <?php if(isset($post->sub_category) && $post->sub_category->count() > 0): ?>
                                                                <a href=""><?php echo e($post->sub_category->name); ?></a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <!-- for mobile -->
                                    <ul class="list-unstyled d-md-none">
                                        <li>1</li>
                                        <li>2</li>
                                        <li>3</li>
                                    </ul>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <li class="nav-item">
                        <?php if(App::getLocale() == 'fr'): ?>
                            <a class="nav-link" href="<?php echo e(LaravelLocalization::getLocalizedURL('ar')); ?>">
                                عربي
                            </a>
                        <?php else: ?>
                            <a class="nav-link" href="<?php echo e(LaravelLocalization::getLocalizedURL('fr')); ?>">
                                French
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- advertisement widget-->
    <div class="mt-3 mb-3">
        <div class="text-center">
            <img src="<?php echo e(asset('assets/frontEnd/img/adv2.webp')); ?>" class="img-fluid" alt="">
        </div>
    </div>
<?php /**PATH C:\Users\Dell\Desktop\news\resources\views/frontEnd/layout/navbar.blade.php ENDPATH**/ ?>
<!-- Footer-->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="<?php echo e(asset('assets/frontEnd/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontEnd/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontEnd/js/owl.carousel.min.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $(".repoerts_carousel .carousel-item:first-child").addClass("active");

    });
</script>

</body>

</html>
<?php /**PATH C:\Users\Dell\Desktop\news\resources\views/frontEnd/layout/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
الاقسام الرئيسية
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- Custom styles for this page -->
    <link href="assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- DataTales Example -->
        <div class="d-flex mb-2">

            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success ml-3">اضافة قسم جديد</a>



            <div id="flash_messages">
                <?php if(session()->has('Add')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="Add">
                        <strong><?php echo e(session()->get('Add')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(session()->has('delete')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" id="delete_alert">
                        <strong><?php echo e(session()->get('delete')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>

        </div>


        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary text-right">الاقسام الرئيسية</h6>
            </div>
            <div class="card-body">



                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>رقم</th>
                                <th>اسم القسم بالعربي</th>
                                <th>اسم القسم بالفرنسي</th>
                                <th>انشاء بواسطة</th>
                                <th>الاجرائات </th>

                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $x = 1;
                            ?>
                        <?php if($categories && $categories->count() > 0): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($x++); ?></td>
                                    <td><?php echo e($category->getTranslation('name','ar')); ?></td>
                                    <td><?php echo e($category->getTranslation('name','fr')); ?></td>
                                    <td><?php echo e($category->user->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-info btn-sm"> تعديل</a>
                                        <!-- Button trigger modal -->
                                        <a href="#exampleModal" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($category->id); ?>" data-name="<?php echo e($category->getTranslation('name','ar')); ?>">
                                            حزف
                                        </a>
                                        <?php echo $__env->make('admin.categories.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            
                            <div class="col-md-6 m-auto text-center">
                                <img src="assets/img/undraw_Empty_re_opql.png" alt="" class="img-fluid">
                                <h2>ليس لديك أي اقسام رئيسية</h2>
                                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">اضافة قسم رئيسي جديد</a>
                            </div>
                            
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php echo $categories->links(); ?>


            </div>
        </div>




    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="assets/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <script>

        $(document).ready(function()
        {
        $('#errors').fadeOut(3000);
        $('#Add').fadeOut(3000);
        $('#delete_alert').fadeOut(3000);
        });
    </script>

    
    <script>

        $('#exampleModal').on('show.bs.modal', function(event)
        {
            // alert("fd");
            var button = $(event.relatedTarget)
            var id = button.data('id')
            // alert(id);
            var name = button.data('name')
            var modal = $(this)
            modal.find('.modal-body #id').val(id);
            modal.find('.modal-body #name').val(name);
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\news\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
@include('frontEnd.layout.header')

<body>

    {{-- start navbar --}}
    @include('frontEnd.layout.navbar')


    <!-- start hero section -->
    @include('frontEnd.layout.hero')
    <!-- End hero section -->

    <!-- start main section -->
    <div class="container p-md-0 mt-4">
        <div class="row p-0">

            <div class="col-md-8 mb-4">
                <!-- start news section -->
                @include('frontEnd.layout.news')

                <!-- end news section -->

                <!-- advertisement widget-->
                <div class="card mb-4 col-12">
                    <div class="card-body text-center">
                        <img src="assets/img/adv2.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start reports section -->
                @include('frontEnd.layout.reports')
                <!-- start reports section -->

                <!-- End reports section -->

                <!-- End reports section -->


                <div class="row mt-4">
                    <!-- start the press section -->
                    @include('frontEnd.layout.press')



                    <!-- start Figures section -->
                    @include('frontEnd.layout.figures')


                </div>


                <!-- Start opinion section -->
                @include('frontEnd.layout.opinion')


                <!-- advertisement widget-->
                <div class="card mb-4 col-12 mt-3">
                    <div class="card-body text-center">
                        <img src="assets/img/adv3.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start sports section -->
                @include('frontEnd.layout.sports')


                <!-- End sports section -->

                <!-- start Mix section -->
                @include('frontEnd.layout.mix')

                <!-- End Mix section -->


            </div>


            <div class="col-md-4">
                <!-- Search widget-->
                <div class="card mb-4">
                    <div class="card-header">Search</div>
                    <div class="card-body">
                        <div class="input-group">
                            <input class="form-control" type="text" placeholder="Enter search term..."
                                aria-label="Enter search term..." aria-describedby="button-search" />
                            <button class="btn btn-primary" id="button-search" type="button">Go!</button>
                        </div>
                    </div>
                </div>
                <!-- advertisement widget-->
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="assets/img/adv1.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- Categories widget-->
                <div class="card mb-4">
                    <div class="card-header">Categories</div>
                    <div class="card-body">
                        <div class="row">
                            @if(isset($categories))
                                @foreach($categories as $category)
                                    <div class="col-sm-6">
                                        <ul class="list-unstyled mb-0">
                                            <li><a href="#!">{{ $category->name }}</a></li>
                                        </ul>
                                    </div>
                                @endforeach
                            @endif

                        </div>
                    </div>
                </div>

                <!-- for Most Read of the Week widget-->
                @include('frontEnd.layout.read_week')


                <!-- start Economie section -->
                @include('frontEnd.layout.economie')


                <!-- start Society section -->
                @include('frontEnd.layout.society')


                <!-- for Most Read widget-->
                @include('frontEnd.layout.most_read')


                <!-- start Economie section -->
                <div class="the_press_section">
                    <div class="card card-body ">
                        <h5>Follow Us</h5>
                        <div class="row social_follow mt-4">
                            <div class="col-3">
                                <i class="bi bi-facebook"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-whatsapp"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-youtube"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-twitter"></i>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>

    @include('frontEnd.layout.footer')


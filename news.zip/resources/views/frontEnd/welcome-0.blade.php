@include('frontEnd.layout.header')
@include('frontEnd.layout.navbar')


    <!-- start hero section -->
    @php
        $data = $categories->first();
        $first_cat_posts = $data
            ->posts()
            ->latest()
            ->take(5)
            ->get();
    @endphp
    <div class="container main-container">
        <div class="hero mt-4">
            <div class="row p-md-0">
                {{-- @if (isset($first_cat_posts[0]->id))
                    <div class="col-md-6 p-md-0">
                        <div class="for_new_post"
                            style="background-image: url('assets/images/{{ $first_cat_posts[0]->photo }}');">
                            <div class="overray"></div>
                            <div class="post_content">
                                <h6 class="mb-4">{{ $first_cat_posts[0]->created_at }}</h6>
                                <h3>
                                    {{ $first_cat_posts[0]->title }}
                                </h3>
                            </div>
                        </div>
                    </div>
                @endif --}}
                <div class="col-md-6">
                    <div class="row pt-2 pt-md-0 p-2 p-md-0">
                        {{-- @if (isset($first_cat_posts[1]->id))
                            <div class="col-6 box_for_new_post_small">
                                <div class="for_new_post_small"
                                    style="background-image: url('assets/images/{{ $first_cat_posts[1]->photo }}');">
                                    <div class="overray"></div>
                                    <div class="post_content">
                                        <p>{{ $first_cat_posts[1]->created_at }}</p>
                                        <h6>
                                            {{ $first_cat_posts[1]->title }}
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if (isset($first_cat_posts[2]->id))
                            <div class="col-6 box_for_new_post_small">
                                <div class="for_new_post_small"
                                    style="background-image: url('assets/images/{{ $first_cat_posts[2]->photo }}');">
                                    <div class="overray"></div>
                                    <div class="post_content">
                                        <p>il y a 1 minute</p>
                                        <h6>
                                            Le président nigérian met en garde contre une intervention étrangère dans
                                            les
                                            prochaines élections présidentielles
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if (isset($first_cat_posts[3]->id))
                            <div class="col-6 box_for_new_post_small">
                                <div class="for_new_post_small"
                                    style="background-image: url('assets/images/{{ $first_cat_posts[3]->photo }}');">
                                    <div class="overray"></div>
                                    <div class="post_content">
                                        <p>{{ $first_cat_posts[3]->created_at }}</p>
                                        <h6>
                                            {{ $first_cat_posts[3]->title }}
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if (isset($first_cat_posts[4]->id))
                            <div class="col-6 box_for_new_post_small">
                                <div class="for_new_post_small"
                                    style="background-image: url('assets/images/{{ $first_cat_posts[4]->photo }}');">
                                    <div class="overray"></div>
                                    <div class="post_content">
                                        <p>{{ $first_cat_posts[4]->created_at }}</p>
                                        <h6>
                                            {{ $first_cat_posts[4]->title }}
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        @endif --}}
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End hero section -->
    {{-- *******************************************************  END SECTION 1 --}}

    <!-- start main section -->
    <div class="container p-md-0 mt-4">
        <div class="row p-0">

            <div class="col-md-8 mb-4">
                <!-- start news section -->
                    <div class="card card-body pt-1 mb-3 MyHover_red">
                        <div class="row card_post_title">
                            <div class="col-6">
                                <h4>{{ $categories[0]->name }}</h4>
                            </div>
                            <div class="col-6 text-end btn_controller_slider">
                                <button><i class="bi bi-chevron-right"></i></button>
                                <button><i class="bi bi-chevron-left"></i></button>
                            </div>

                        </div>

                        <div class="row mt-2 card_small_news">

                            @php
                                $data = $categories->first();
                                $first_cat_all_posts = $data
                                    ->posts()
                                    ->latest()
                                    ->get();
                            @endphp

                            {{-- @if (isset($first_cat_all_posts) && $first_cat_all_posts->count() > 0)

                                @foreach ($first_cat_all_posts as $posts2)
                                    <div class="col-md-6 mt-3">
                                        <div>
                                            <div class="date text-black-50 mb-1">
                                                <i class="bi bi-clock"></i>
                                                <span>{{ $posts2->created_at }}</span>
                                            </div>
                                            <h5>{{ $posts2->title }}</h5>
                                        </div>

                                        <div class="row">
                                            <div class="col-4">
                                                <img class="img-fluid m-auto"
                                                    src="{{ asset('/assets/images/' . $posts2->photo) }}" alt="">
                                            </div>
                                            <div class="col-8">
                                                <div class="desc">
                                                    <p>
                                                        {{ substr($posts2->body, 0, 100) }}...
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif --}}
                        </div>
                    </div>
                <!-- end news section -->

                <!-- advertisement widget-->
                <div class="card mb-4 col-12">
                    <div class="card-body text-center">
                        <img src="{{ asset('assets/frontEnd/img/adv2.webp') }}" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start reports section -->
                @for ($x = 0; $x < $chunk_news->count(); $x++)
                    <div class="card card-body pt-1 MyHover_red">
                        @foreach ($chunk_news[$x] as $item)
                        @php
                           $da =  head($item);
                        //    dd($item->title);
                        @endphp
                            {{ $item }}
                        @endforeach
                    </div>
                @endfor
                <!-- End reports section -->


                <div class="row mt-4">
                    <!-- start the press section -->
                    <div class="col-md-6 the_press_section mb-3">
                        <div class="card card-body MyHover_blue">
                            <div class="row card_title">
                                <div class="col-6">
                                    <h4>the press</h4>
                                </div>

                                <div class="col-6 text-end btn_controller_slider">
                                    <button><i class="bi bi-chevron-right"></i></button>
                                    <button><i class="bi bi-chevron-left"></i></button>
                                </div>

                            </div>

                            <img src="assets/img/القصر.webp" class="img-fluid" alt="">
                            <div class="medium_text mt-2 mb-1"> <i class="bi bi-clock"></i> time here</div>
                            <h4>Ligue des champions : une finale avant la lettre</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime placeat minima
                                consequatur
                            </p>

                            <div class="row mt-3">
                                <div class="col-5">
                                    <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                                </div>
                                <div class="col-7">
                                    <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                    <h6>title here</h6>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-5">
                                    <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                                </div>
                                <div class="col-7">
                                    <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                    <h6>title here</h6>
                                </div>
                            </div>


                        </div>
                    </div>


                    <!-- start Figures section -->
                    <div class="col-md-6 Figures_section">
                        <div class="card card-body MyHover_green">
                            <div class="row card_title">
                                <div class="col-6">
                                    <h4>Figures</h4>
                                </div>
                                <div class="col-6 text-end btn_controller_slider">
                                    <button><i class="bi bi-chevron-right"></i></button>
                                    <button><i class="bi bi-chevron-left"></i></button>
                                </div>
                            </div>
                            <img src="assets/img/carousel-1.jpg" class="img-fluid" alt="">
                            <div class="medium_text mt-2 mb-1"> <i class="bi bi-clock"></i> time here</div>
                            <h4>Ligue des champions : une finale avant la lettre</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime placeat minima
                                consequatur
                            </p>

                            <div class="row mt-3">
                                <div class="col-5">
                                    <img class="img-fluid" src="assets/img/carousel-1.jpg" alt="">
                                </div>
                                <div class="col-7">
                                    <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                    <h6>title here</h6>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-5">
                                    <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                                </div>
                                <div class="col-7">
                                    <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                    <h6>title here</h6>
                                </div>
                            </div>


                        </div>
                    </div>

                </div>

                <!-- Start opinion section -->
                    {{-- @if (isset($openioun_posts[0]->category->name))
                        <div class="col-12 mt-4 pt-2 ">
                            <div class="card card-body Opinion_section MyHover_blue">
                                <div class="row card_title">
                                    <div class="col-6">
                                        <h4>{{ $openioun_posts[0]->category->name }}</h4>
                                    </div>
                                    <div class="col-6 text-end btn_controller_slider">
                                        <button><i class="bi bi-chevron-right"></i></button>
                                        <button><i class="bi bi-chevron-left"></i></button>
                                    </div>
                                </div>
                                <div dir="ltr" class="owl-carousel owl-theme mt-3">

                                    @foreach ($openioun_posts as $openioun)
                                        <div class="item">
                                            <div class="mb-4">
                                                <img src="{{ asset('assets/images/'.$openioun->photo) }}" alt="" class="img-fluid">
                                                <div class="date mb-2 mt-1 small_text">
                                                    <i class="bi bi-clock"></i>
                                                    <span>{{ $openioun->created_at }}</span>
                                                </div>
                                                <h6>{{ $openioun->title }}</h6>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    @endif --}}
                 <!-- end opinion section -->


                <!-- advertisement widget-->
                <div class="card mb-4 col-12 mt-3">
                    <div class="card-body text-center">
                        <img src="{{ asset('assets/frontEnd/img/adv3.webp') }}" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- start sports section -->
                    {{-- @if (isset($sport_posts[0]->category->name))
                        <div class="card card-body pt-1 sports_section MyHover_green">
                            <div class="row card_title">
                                <div class="col-6">
                                    <h4>{{$sport_posts[0]->category->name}}</h4>
                                </div>
                                <div class="col-6 text-end btn_controller_slider">
                                    @if (isset($last_sports_id->id))
                                        <button id="back_sport" post_id="{{ $first_sports_id->id }}" lang="{{ app()->getLocale() }}">
                                            <i class="bi bi-chevron-right"></i>
                                        </button>
                                    @endif
                                    @if (isset($first_sports_id->id))
                                        <button id="next_sport" post_id="{{ $last_sports_id->id }}" lang="{{ app()->getLocale() }}">
                                            <i class="bi bi-chevron-left"></i>
                                        </button>
                                    @endif
                                </div>
                            </div>

                            <div class="row mt-2 card_small_reports" id="results_sport">

                                @if (isset($sport_posts[0]->photo))
                                    <div class="main_post_for_reports mb-3"
                                        style="background-image:  url('assets/images/{{ $sport_posts[0]->photo }}')">
                                        <div class="overray"></div>
                                        <div class="post_content">
                                            <h6 class="mb-4">{{ $sport_posts[0]->created_at }}</h6>
                                            <h3>
                                                {{ $sport_posts[0]->title }}
                                            </h3>
                                        </div>
                                    </div>
                                @endif


                            @if (isset($sport_posts[1]->photo))
                                    <div class="col-6 col-md-4">
                                        <img src="{{ asset('assets/images/'.$sport_posts[1]->photo) }}" class="img-fluid" alt="">
                                        <div class="date mb-1 mt-1 small_text">
                                            <i class="bi bi-clock"></i>
                                            <span>{{ $sport_posts[1]->created_at }}</span>
                                        </div>
                                        <h6>{{ $sport_posts[1]->title }}</h6>
                                    </div>
                            @endif

                            @if (isset($sport_posts[2]->photo))
                                    <div class="col-6 col-md-4">
                                        <img src="{{ asset('assets/images/'.$sport_posts[2]->photo) }}" class="img-fluid" alt="">
                                        <div class="date mb-1 mt-1 small_text">
                                            <i class="bi bi-clock"></i>
                                            <span>{{ $sport_posts[2]->created_at }}</span>
                                        </div>
                                        <h6>{{ $sport_posts[2]->title }}</h6>
                                    </div>
                            @endif

                            @if (isset($sport_posts[3]->photo))
                                    <div class="col-6 col-md-4">
                                        <img src="{{ asset('assets/images/'.$sport_posts[3]->photo) }}" class="img-fluid" alt="">
                                        <div class="date mb-1 mt-1 small_text">
                                            <i class="bi bi-clock"></i>
                                            <span>{{ $sport_posts[3]->created_at }}</span>
                                        </div>
                                        <h6>{{ $sport_posts[3]->title }}</h6>
                                    </div>
                            @endif
                            </div>
                        </div>
                    @endif --}}
                <!-- End sports section -->


                <!-- start Mix section -->
                    <div class="card card-body pt-1 mix_section mt-4 MyHover">
                        <div class="row card_title">
                            <div class="col-6">
                                @php
                                    $category_mix = App\Models\Category::find('7');
                                @endphp
                                {{-- @if (isset($category_mix))
                                        <h4>{{ $category_mix->name }}</h4>
                                @endif --}}
                            </div>
                            <div class="col-6 text-end btn_controller_slider">
                                {{-- @if (isset($first_mix_id->id))
                                    <button id="back_mix" post_id="{{ $first_mix_id->id }}" lang="{{ app()->getLocale() }}">
                                        <i class="bi bi-chevron-right"></i>
                                    </button>
                                @endif
                                @if (isset($last_mix_id->id))
                                    <button id="next_mix" post_id="{{ $last_mix_id->id }}" lang="{{ app()->getLocale() }}">
                                        <i class="bi bi-chevron-left"></i>
                                    </button>
                                @endif --}}
                            </div>
                        </div>

                        <div class="row mt-2 card_small_reports" id="results_mix">

                            <div class="col-md-6">
                            {{-- @if (isset($mix_posts[0]->title))
                                <div class="main_post_for_mix mb-4" style="background-image: url('assets/images/{{ $mix_posts[0]->photo }}');">
                                    <div class="overray"></div>
                                    <div class="post_content">
                                        <h6 class="mb-4">{{ $mix_posts[0]->created_at }}</h6>
                                        <h3>
                                        {{ $mix_posts[0]->title }}
                                        </h3>
                                    </div>
                                </div>
                            @endif --}}
                            </div>

                            <div class="col-md-6">
                                {{-- @if (isset($mix_posts[1]->title))
                                    <div class="col-12 row mb-4">
                                        <div class="col-5">
                                            <img class="img-fluid" src="{{ asset('assets/images/'.$mix_posts[1]->photo) }}" alt="">
                                        </div>
                                        <div class="col-7">
                                            <div class="small_text mt-1"> <i class="bi bi-clock"></i>{{ $mix_posts[1]->created_at }}</div>
                                            <h6>{{ $mix_posts[1]->title }}</h6>
                                        </div>
                                    </div>
                                @endif --}}

                                {{-- @if (isset($mix_posts[2]->title))
                                    <div class="col-12 row mb-4">
                                        <div class="col-5">
                                            <img class="img-fluid" src="{{ asset('assets/images/'.$mix_posts[2]->photo) }}" alt="">
                                        </div>
                                        <div class="col-7">
                                            <div class="small_text mt-1"> <i class="bi bi-clock"></i>{{ $mix_posts[2]->created_at }}</div>
                                            <h6>{{ $mix_posts[2]->title }}</h6>
                                        </div>
                                    </div>
                                @endif --}}

                                {{-- @if (isset($mix_posts[3]->title))
                                    <div class="col-12 row mb-4">
                                        <div class="col-5">
                                            <img class="img-fluid" src="{{ asset('assets/images/'.$mix_posts[3]->photo) }}" alt="">
                                        </div>
                                        <div class="col-7">
                                            <div class="small_text mt-1"> <i class="bi bi-clock"></i>{{ $mix_posts[3]->created_at }}</div>
                                            <h6>{{ $mix_posts[3]->title }}</h6>
                                        </div>
                                    </div>
                                @endif --}}
                            </div>

                        </div>

                    </div>
                <!-- End Mix section -->
            </div>


            <div class="col-md-4">
                <!-- Search widget-->
                <div class="card mb-4">
                    <div class="card-header">{{  __('welcome.search')}}</div>
                    <div class="card-body">
                        <div class="input-group">
                            <form action="{{ route('search.frontEnd') }}" method="post">
                                @csrf
                                <input class="form-control" type="text" placeholder="Enter search term..." aria-label="Enter search term..." aria-describedby="button-search"  name="search"/>
                                <input type="submit" value="Go!" class="btn btn-success btn-sm">
                            </form>
                        </div>
                    </div>
                </div>
                <!-- advertisement widget-->
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="assets/img/adv1.webp" class="img-fluid" alt="">
                    </div>
                </div>

                <!-- Categories widget-->
                <div class="card mb-4">
                    <div class="card-header">Categories</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#!">Web Design</a></li>
                                    <li><a href="#!">HTML</a></li>
                                    <li><a href="#!">Freebies</a></li>
                                </ul>
                            </div>
                            <div class="col-sm-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#!">JavaScript</a></li>
                                    <li><a href="#!">CSS</a></li>
                                    <li><a href="#!">Tutorials</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- for Most Read of the Week widget-->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row card_title">
                            <div class="col-8">
                                <h6>Most Read of the Week</h6>
                            </div>
                            <div class="col-4 text-end btn_controller_slider">
                                <button><i class="bi bi-chevron-right"></i></button>
                                <button><i class="bi bi-chevron-left"></i></button>
                            </div>
                        </div>
                        <hr>
                        <div class="row mb-2">
                            <div class="col-6">
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-6">
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- start Economie section -->
                <div class="Economie_section">
                    <div class="card card-body ">
                        <div class="row card_title">
                            <div class="col-8">
                                <h5>Economie</h5>
                            </div>
                            <div class="col-4 text-end btn_controller_slider">
                                <button><i class="bi bi-chevron-right"></i></button>
                                <button><i class="bi bi-chevron-left"></i></button>
                            </div>
                        </div>
                        <img src="assets/img/القصر.webp" class="img-fluid" alt="">
                        <div class="medium_text mt-2 mb-1"> <i class="bi bi-clock"></i> time here</div>
                        <h4>Ligue des champions : une finale avant la lettre</h4>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime placeat minima consequatur
                        </p>

                        <div class="row mt-3">
                            <div class="col-5">
                                <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                            </div>
                            <div class="col-7">
                                <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                <h6>title here</h6>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-5">
                                <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                            </div>
                            <div class="col-7">
                                <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                <h6>title here</h6>
                            </div>
                        </div>


                    </div>
                </div>


                <!-- start Society section -->
                <div class="Economie_section mt-3">
                    <div class="card card-body ">
                        <div class="row card_title">
                            <div class="col-8">
                                <h5>Society</h5>
                            </div>
                            <div class="col-4 text-end btn_controller_slider">
                                <button><i class="bi bi-chevron-right"></i></button>
                                <button><i class="bi bi-chevron-left"></i></button>
                            </div>
                        </div>
                        <img src="assets/img/القصر.webp" class="img-fluid" alt="">
                        <div class="medium_text mt-2 mb-1"> <i class="bi bi-clock"></i> time here</div>
                        <h4>Ligue des champions : une finale avant la lettre</h4>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime placeat minima consequatur
                        </p>

                        <div class="row mt-3">
                            <div class="col-5">
                                <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                            </div>
                            <div class="col-7">
                                <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                <h6>title here</h6>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-5">
                                <img class="img-fluid" src="assets/img/carousel-2.jpg" alt="">
                            </div>
                            <div class="col-7">
                                <div class="small_text mt-1"> <i class="bi bi-clock"></i> time here</div>
                                <h6>title here</h6>
                            </div>
                        </div>


                    </div>
                </div>

                <!-- for Most Read widget-->
                <div class="card mb-4 mt-4">
                    <div class="card-body">

                        <div class="row card_title">
                            <div class="col-8">
                                <h5 class="text-success">Most Read</h5>
                            </div>
                            <div class="col-4 text-end btn_controller_slider">
                                <button><i class="bi bi-chevron-right"></i></button>
                                <button><i class="bi bi-chevron-left"></i></button>
                            </div>
                        </div>

                        <hr>
                        <div class="row mb-2 mt-4">
                            <div class="col-6 most_read_count">
                                <div class="most_read_count_1">1</div>
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>
                        <div class="row mb-2 mt-4">
                            <div class="col-6 most_read_count">
                                <div class="most_read_count_1">2</div>
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>
                        <div class="row mb-2 mt-4">
                            <div class="col-6 most_read_count">
                                <div class="most_read_count_1">3</div>
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>
                        <div class="row mb-2 mt-4">
                            <div class="col-6 most_read_count">
                                <div class="most_read_count_1">4</div>
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>

                        <div class="row mb-2 mt-4">
                            <div class="col-6 most_read_count">
                                <div class="most_read_count_1">5</div>
                                <img class="img-fluid" src="assets/img/القصر.webp" alt="">
                            </div>
                            <div class="col-6 p-0">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <p class="small_text"><i class="bi bi-clock"></i> il y a 1 seconde</p>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- start Economie section -->
                <div class="the_press_section">
                    <div class="card card-body ">
                        <h5>Follow Us</h5>
                        <div class="row social_follow mt-4">
                            <div class="col-3">
                                <i class="bi bi-facebook"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-whatsapp"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-youtube"></i>
                            </div>
                            <div class="col-3">
                                <i class="bi bi-twitter"></i>
                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>
    </div>


   @include('frontEnd.layout.footer')
